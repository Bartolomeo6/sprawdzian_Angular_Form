import { Routes } from '@angular/router';
import { FunkcjaKwadComponent } from './funkcja-kwad/funkcja-kwad.component';
import { RejestracjaComponent } from './rejestracja/rejestracja.component';
import { SerwisMatmaComponent } from './serwis-matma/serwis-matma.component';

export const routes: Routes = [
  {path: "", component: SerwisMatmaComponent},
  {path: "delta", component: FunkcjaKwadComponent},
  {path: "rejestracja", component: RejestracjaComponent}
];
