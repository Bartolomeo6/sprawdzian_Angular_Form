import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import {FormsModule} from '@angular/forms';

@Component({
  selector: 'app-rejestracja',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './rejestracja.component.html',
  styleUrl: './rejestracja.component.css'
})
export class RejestracjaComponent {
  emailOsoby: string = "";
  hasloOsoby: string = "";
  powtHasloOsoby: string = "";
  czyZawieraMalpe: boolean = true;
  czyTakieSame: boolean = true;
  zatwierdz(){
    if(!this.emailOsoby.includes("@")){
      this.czyZawieraMalpe = false;
    }
    else{
      this.czyZawieraMalpe = true;
    }
    if(this.hasloOsoby != this.powtHasloOsoby){
      this.czyTakieSame = false;
    }
    else{
      this.czyTakieSame = true;
    }
  }
}
