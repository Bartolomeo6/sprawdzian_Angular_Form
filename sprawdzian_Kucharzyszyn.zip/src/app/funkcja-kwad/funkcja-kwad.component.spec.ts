import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FunkcjaKwadComponent } from './funkcja-kwad.component';

describe('FunkcjaKwadComponent', () => {
  let component: FunkcjaKwadComponent;
  let fixture: ComponentFixture<FunkcjaKwadComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [FunkcjaKwadComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FunkcjaKwadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
