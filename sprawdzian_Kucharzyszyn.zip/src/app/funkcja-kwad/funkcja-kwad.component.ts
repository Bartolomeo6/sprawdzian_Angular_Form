import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import {FormsModule} from '@angular/forms';

@Component({
  selector: 'app-funkcja-kwad',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './funkcja-kwad.component.html',
  styleUrl: './funkcja-kwad.component.css'
})
export class FunkcjaKwadComponent {
  a: number = 0;
  b: number = 0;
  c: number = 0;
  p: number = 0;
  q: number = 0;
  x1: number = 0;
  x2: number = 0;
  x0: number = 0;
  komunikat: string = "";
  delta: number = 0;

  oblicz(){
    this.delta = (this.b*this.b)-(4*(this.a*this.c));
    this.p = (-(this.b))/(2*this.a);
    this.q = (-(this.delta))/(4*this.a);
    if(this.delta > 0){
      this.x1 = (-(this.b)-Math.sqrt(this.delta))/(2*this.a);
      this.x2 = (-(this.b)+Math.sqrt(this.delta))/(2*this.a);
    }
    else if(this.delta == 0){
      this.x0 = (-(this.b))/(2*this.a);
    }
    else{
      this.komunikat = "Brak pierwiastków";
    }
  }
}
