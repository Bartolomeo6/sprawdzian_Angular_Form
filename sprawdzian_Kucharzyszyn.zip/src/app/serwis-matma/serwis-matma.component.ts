import { Component } from '@angular/core';
import { Router, RouterLink, RouterOutlet } from '@angular/router';
import { FunkcjaKwadComponent } from '../funkcja-kwad/funkcja-kwad.component';

@Component({
  selector: 'app-serwis-matma',
  standalone: true,
  imports: [RouterLink, RouterOutlet, FunkcjaKwadComponent],
  templateUrl: './serwis-matma.component.html',
  styleUrl: './serwis-matma.component.css'
})
export class SerwisMatmaComponent {

}
