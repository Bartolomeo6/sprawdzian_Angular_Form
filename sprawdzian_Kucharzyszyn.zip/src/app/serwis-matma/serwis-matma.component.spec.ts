import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SerwisMatmaComponent } from './serwis-matma.component';

describe('SerwisMatmaComponent', () => {
  let component: SerwisMatmaComponent;
  let fixture: ComponentFixture<SerwisMatmaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SerwisMatmaComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SerwisMatmaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
